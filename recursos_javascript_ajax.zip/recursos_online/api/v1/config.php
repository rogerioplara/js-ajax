<?php

define('MYSQL_HOST',        'localhost');
define('MYSQL_DATABASE',    'ajax_api');
define('MYSQL_USERNAME',    'root');
define('MYSQL_PASSWORD',    '');